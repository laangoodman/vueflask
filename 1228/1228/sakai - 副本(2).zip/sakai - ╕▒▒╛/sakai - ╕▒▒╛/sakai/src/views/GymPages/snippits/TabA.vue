<script setup>

import ChangDiYuDing from '@/views/GymPages/snippits/ChangDiYuDing.vue';
import ShangPin from '@/views/GymPages/snippits/ShangPin.vue';
import CiKa from '@/views/GymPages/snippits/CiKa.vue';
import MenPiao from '@/views/GymPages/snippits/MenPiao.vue';
import AASearchMenPiao from '@/views/GymPages/snippits/AASearchMenPiao.vue';

</script>

<template>
<TabView>
                        
    <TabPanel header="场地租用">
        <ChangDiYuDing/>
    </TabPanel>
    <TabPanel header="商品销售">
        <ShangPin/>
    </TabPanel>
    <TabPanel header="次卡销售">
        <CiKa/>
    </TabPanel>
    <TabPanel header="门票销售">
        <AASearchMenPiao/>
        <MenPiao/>
    </TabPanel>

</TabView>
</template>