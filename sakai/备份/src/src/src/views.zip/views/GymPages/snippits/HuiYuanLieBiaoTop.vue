<template>

    <div class="surface-ground px-4 py-5 md:px-6 lg:px-8">
        <div class="grid">

            
            <div class="col-12 md:col-6 lg:col-3" >
                <div class="surface-card shadow-2 p-3 border-round" style="height: 200px;">
                    
                    <div class="flex justify-content-between mb-3">
                        <div>
                            <span class="block text-500 font-medium mb-3"></span>
                            <div class="text-900 font-medium text-sm">今日新增</div>
                        </div>
                      
                    </div>
                    <span class="text-red-500 font-medium">3 </span>
                    
                        <div>                    
                            <span class="block text-500 font-medium mb-8"></span>
                            <div class="text-900 font-medium text-sm">近7天</div>
                        </div>

                </div>
                
            </div>
    
            <div class="col-12 md:col-6 lg:col-3" >
                <div class="surface-card shadow-2 p-3 border-round" style="height: 200px;">
                    
                    <div class="flex justify-content-between mb-3">
                        <div>
                            <span class="block text-500 font-medium mb-3"></span>
                            <div class="text-900 font-medium text-sm">今日新增</div>
                        </div>
                      
                    </div>
                    <span class="text-red-500 font-medium">3 </span>
                    
                        <div>                    
                            <span class="block text-500 font-medium mb-8"></span>
                            <div class="text-900 font-medium text-sm">近7天</div>
                        </div>

                </div>
                
            </div>
    
            <div class="col-12 md:col-6 lg:col-3" >
                <div class="surface-card shadow-2 p-3 border-round" style="height: 200px;">
                    
                    <div class="flex justify-content-between mb-3">
                        <div>
                            <span class="block text-500 font-medium mb-3"></span>
                            <div class="text-900 font-medium text-sm">今日新增</div>
                        </div>
                      
                    </div>
                    <span class="text-red-500 font-medium">3 </span>
                    
                        <div>                    
                            <span class="block text-500 font-medium mb-8"></span>
                            <div class="text-900 font-medium text-sm">近7天</div>
                        </div>

                </div>
                
            </div>
  <div class="col-12 md:col-6 lg:col-3" >
                <div class="surface-card shadow-2 p-3 border-round" style="height: 200px;">
                    
                    <div class="flex justify-content-between mb-3">
                        <div>
                            <span class="block text-500 font-medium mb-3"></span>
                            <div class="text-900 font-medium text-sm">今日新增</div>
                        </div>
                      
                    </div>
                    <span class="text-red-500 font-medium">3 </span>
                    
                        <div>                    
                            <span class="block text-500 font-medium mb-8"></span>
                            <div class="text-900 font-medium text-sm">近7天</div>
                        </div>

                </div>
                
            </div>
      
    
        
    
    
    
    
    
            
        </div>
    </div>
    
    
    
    </template>