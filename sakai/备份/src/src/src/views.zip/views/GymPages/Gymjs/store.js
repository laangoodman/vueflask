import { reactive } from 'vue';

export const store = reactive({
  newButtonVisible: false
});