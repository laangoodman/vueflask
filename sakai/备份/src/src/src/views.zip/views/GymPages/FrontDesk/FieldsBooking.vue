<script setup>
import { ref } from 'vue';
import AASearchUser from '@/views/GymPages/snippits/AASearchUser.vue';
import ChangDiYuDing from '@/views/GymPages/snippits/ChangDiYuDing.vue';
// import ChangDiYuDing2 from '@/views/GymPages/snippits/ChangDiYuDing.vue';

import { FilterMatchMode } from 'primevue/api';
import { onMounted, onBeforeMount } from 'vue';
import ProductService from '@/service/ProductService';
import { useToast } from 'primevue/usetoast';

import { store } from '@/views/GymPages/Gymjs/store.js'; // Adjust the path as needed


const isUserSearchButtonVisible = ref(false);


</script>

<template> 


    <div class="grid">    
        <div class="col-12 md:col-4">
            <!-- 页面左边 -->




            <AASearchUser/>
        </div>

        <div class="col-12 md:col-8">
            <!-- 页面右边 -->



            <ChangDiYuDing/>
        </div>
    </div>
    
</template>

<style lang="scss" scoped></style>
