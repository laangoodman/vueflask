<script setup>
  import HuiYuanLieBiaoTop from '@/views/GymPages/snippits/HuiYuanLieBiaoTop.vue';
  import AASearchMember from '@/views/GymPages/snippits/AASearchMember.vue';
  import HuiYuanList from '@/views/GymPages/snippits/HuiYuanList.vue';

</script>


<template>
  <div class="grid">
    

      <div class="col-12 ">


      <HuiYuanLieBiaoTop/>

      </div>

      <div class="col-12 ">


      <AASearchMember/>

      </div>

      <div class="col-12 ">


      <HuiYuanList/>

      </div>
  
  </div>
</template>
