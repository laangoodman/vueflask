<template>
    <div class="card">
        <div class="formgroup-inline">
            <div class="field">
                <InputText type="text"   />
                <Button type="button" label="核销"  v-tooltip="'Click to proceed' " class=" ml-2" />
            </div>
        </div>
    </div>
</template>