<script setup>
  import HuiYuanLieBiaoTop from '@/views/GymPages/snippits/HuiYuanLieBiaoTop.vue';
  import AASearchMember from '@/views/GymPages/snippits/AASearchMember.vue';
  import HuiYuanInfo from '@/views/GymPages/snippits/HuiYuanInfo.vue';

</script>


<template>
  <div class="grid">
    

 

      <div class="col-12 ">


      <AASearchMember/>

      </div>

      <div class="col-12 ">


      <HuiYuanInfo/>

      </div>
  
  </div>
</template>
