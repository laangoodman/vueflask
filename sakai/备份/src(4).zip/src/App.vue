<script setup>
// 使用 <script setup> 定义组件逻辑

</script>

<template>
    <!-- 组件模板 -->
    <router-view />
    <!-- <router-view> 用于显示当前路由的组件内容 -->
</template>

<style scoped>
/* 组件样式，scoped 表示样式仅在当前组件内部生效 */

</style>