<script setup>

import ChangDiYuDing from '@/views/GymPages/snippits/ChangDiYuDing.vue';
import ShangPin from '@/views/GymPages/snippits/ShangPin.vue';
import CiKa from '@/views/GymPages/snippits/CiKa.vue';
import MenPiao from '@/views/GymPages/snippits/MenPiao.vue';
import AASearchMenPiao from '@/views/GymPages/snippits/AASearchMenPiao.vue';

</script>

<template>
        <ChangDiYuDing/>
</template>