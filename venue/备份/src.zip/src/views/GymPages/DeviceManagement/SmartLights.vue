
<script setup>
import DDModal from '@/views/GymPages/snippits/DDModal.vue';

</script>


<template>

<div class="grid">

    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>
    <div class="col-12 md:col-6 lg:col-3">
        <div class="surface-card shadow-2 p-3 border-round">
            <div class="flex justify-content-between mb-3">
                <div>
                    <span class="block text-500 font-medium mb-3">空闲</span>
                    <div class="text-900 font-medium text-xl">羽毛球1</div>
                </div>
                    
            </div>
                <DDModal/>
                                   
        </div>
    </div>


</div>

</template>