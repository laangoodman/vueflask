<template>

<div class="card">
    <TabView>
        
        <TabPanel header="全部扣次">
    
        </TabPanel>



    </TabView>
</div>
    
    
</template>