<script setup>
import { ref } from 'vue';
import AASearchMenPiao from '@/views/GymPages/snippits/AASearchMenPiao.vue';
import MenPiao from '@/views/GymPages/snippits/MenPiao.vue';


const dropdownItems = ref([
    { name: 'Option 1', code: 'Option 1' },
    { name: 'Option 2', code: 'Option 2' },
    { name: 'Option 3', code: 'Option 3' }
]);

const dropdownItem = ref(null);
</script>

<template>
    <div class="grid">
        <div class="col-12">
            <cards>
                <div class="formgroup-inline">                
                    <div class="field">
                        <InputText type="text" placeholder="" v-tooltip="'Your username'" @click="openNew"/>
                    </div>                    
                        <Button type="button" label="核销"  v-tooltip="'Click to proceed'"   />                   
                    <div class="ml-2">
                        <BBModal/>   
                    </div>
                </div>
            </cards>
 
        </div>
        <div class="col-12 ">
            <div class="card">
                <DataTable :value="customer3" rowGroupMode="subheader" groupRowsBy="representative.name" sortMode="single" sortField="representative.name" :sortOrder="1" scrollable scrollHeight="400px" class="p-datatable-gridlines">
                    <Column field="representative.name" header="Representative"></Column>
                    <Column field="标号" header="#"></Column>

                    <Column field="name" header="订单号" style="min-width: 150px"></Column>
                    <Column field="country" header="会员卡号" style="min-width: 150px">
                   
                    </Column>
                    <Column field="company" header="会员名称" style="min-width: 150px"></Column>
                    <Column field="status" header="核销时间" style="min-width: 150px">
                       
                    </Column>
                    <Column field="date" header="预约时间" style="min-width: 200px"></Column>
                    <Column field="date" header="区域" style="min-width: 150px"></Column>
                    <Column field="date" header="场地" style="min-width: 150px"></Column>
                    <Column field="date" header="备注" style="min-width: 200px"></Column>
              
                </DataTable>
            </div>

        </div>
    
    </div>
</template>
